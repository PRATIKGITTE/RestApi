package com.cdac.training.pmss.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cdac.training.pmss.model.product;
import com.cdac.training.pmss.repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public void saveProduct(product product) {
        productRepository.save(product);
    }
}
