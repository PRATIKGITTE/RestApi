package com.cdac.training.pmss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PmssApplication {

    public static void main(String[] args) {
        SpringApplication.run(PmssApplication.class, args);
    }
}
