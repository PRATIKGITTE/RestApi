package com.cdac.training.pmss.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cdac.training.pmss.model.product;

public interface ProductRepository extends JpaRepository<product, Long> {
}
