package com.cdac.training.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsRestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmsRestapiApplication.class, args);
	}

}
